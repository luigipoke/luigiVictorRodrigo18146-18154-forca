#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"


int main()
{
    NoSecreto * listaSecreta = inicializaListaSecreta();

   listaSecreta = carregaListaArquivo(listaSecreta, "D:\\ED\\forcaCerto\\palavras.dat");
   imprimeListaSecreta(listaSecreta);
}
